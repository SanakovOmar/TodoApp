﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Todoapp.Models
{
    class TodoModel: INotifyPropertyChanged
    {
        
		private bool _isDone;
        private String _Text;
        private string _Text1;

        public DateTime CreationDate { get; set; } = DateTime.Now;
        public bool IsDone
		{
			get { return _isDone; }
			set 
			{
				if (_isDone == value)
					return;
				_isDone = value; 
				OnPropertyChanged("IsDone");
			}
		}
		public String Text
		{
			get { return _Text; }
			set 
			{
				if (_Text == value)
					return;
				_Text = value; 
				OnPropertyChanged("Text");
			}
		}

        public String Text1
        {
            get { return _Text1; }
            set
            {
                if (_Text1 == value)
                    return;
                _Text1 = value;
                OnPropertyChanged("Text");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

		protected virtual void OnPropertyChanged(string propertyName = " ")
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}
    }
}
